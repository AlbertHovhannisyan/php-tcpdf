<?php

$templates = Array(
    Array(
        "title" => "title 1",
        "content" => "<span>Title 1</span>",
    ),
    Array(
        "title" => "title 2",
        "content" => "<span>Title 2 Title 2</span>",
    ),
    Array(
        "title" => "title 3",
        "content" => "<span>Title 3 Title 3 Title 3</span>",
    ),
);
